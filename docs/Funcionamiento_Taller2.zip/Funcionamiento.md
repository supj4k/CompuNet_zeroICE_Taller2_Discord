## informe técnico de funcionamiento

Aclaración importante del estado del proyecto: es un proyecto Gradle multimódulo con tres subproyectos (`common`, `server`, `client`). En `common` está el contrato `Chat.ice`, y de ahí `slice2java` genera el código Java que usan tanto el server como el cliente. Para compilarlo nos ubicamos en la raíz del proyecto, que en este caso es `Imple/Discord_ICE`, y digitamos el siguiente comando:

`.\gradlew clean build`

Igual que en el taller pasado usamos el wrapper (`.\gradlew`) y no `gradle` directo, para que todos los integrantes usemos la misma versión de Gradle (8.14) sin depender de lo que cada uno tenga instalado. En este build se dispara la tarea `compileSlice`, que invoca a `slice2java` sobre `Chat.ice`, y además corren las pruebas de JUnit del server.

Lo que está funcionando y se prueba en este documento:

| Requerimiento | Qué hace | Quién |
|---|---|---|
| RF-01 | Login, presencia en tiempo real con callbacks, `/users` | JD |
| RF-02 | Mensajes privados | JD |
| RF-04 | Envío de archivos por chunks de 64 KB (`sequence<byte>`) | Andrés |
| RF-05 | Llamada de voz 1 a 1: señalización por Ice y audio por UDP | Andrés |

RF-03 (salas) y RF-06 (llamada grupal) son de Emmanuel; cuando estén unidos en `dev` se agregan sus pruebas acá con el mismo formato.

## Funcionamiento Código

Para estas pruebas abrimos 4 terminales: una para el server y tres para los clientes (`Alice`, `Bob` y `Carlos`). Algo importante es que los clientes **no** se conectan con `localhost`, sino con la IP del equipo donde corre el server (en esta corrida `192.0.2.2`; en la prueba con dos PCs fue `192.168.1.16`). Esto es porque el server usa la IP desde la que le llega cada cliente para armar la dirección del audio de las llamadas, y si alguien entra por `localhost` el server le pasaría `127.0.0.1` a los demás y el audio nunca les llegaría.

Primero ponemos a correr el server. Nos ubicamos en la raíz del proyecto y ejecutamos:

`.\gradlew :server:runServer`

![Server esperando clientes](imgFun/01_ServerEsperandoClientes.png)

```text
[SERVER] Escuchando en: tcp -p 10000
[SERVER] Ctrl+C para detener
```

ahí el server está corriendo bien; leyó `config.server`, creó el `ObjectAdapter` con el endpoint `tcp -p 10000` (sin `-h`, o sea que escucha en todas las interfaces, que es lo que necesitamos para la demo en red) y registró el objeto con la identidad `ChatServer`. En ese mismo archivo le subimos el ThreadPool del server a 4 hilos (hasta 16), porque con callbacks un solo hilo se puede bloquear.

### Prueba 1 — Inicio de sesión y presencia (RF-01)

En una segunda terminal levantamos el primer cliente pasándole la IP del server, y en una tercera el segundo cliente:

`.\gradlew :client:runClient -Pserver=192.0.2.2`

![Login de Alice y Bob](imgFun/02_LoginAliceYBob.png)

```text
--- Alice ---
[CLIENT] Conectando a: ChatServer:tcp -h 192.0.2.2 -p 10000
Nickname: Alice
[CLIENT] Sesión iniciada como Alice. /help para ver comandos.
[CLIENT] Conectados: Alice
[+] Bob se conectó

--- Bob ---
Nickname: Bob
[CLIENT] Sesión iniciada como Bob. /help para ver comandos.
[CLIENT] Conectados: Alice, Bob

--- Server ---
[SERVER] Sesión iniciada: Alice
[SERVER] Sesión iniciada: Bob
```

los dos quedaron autenticados y lo importante es la línea `[+] Bob se conectó` en la terminal de Alice: Alice no preguntó nada, fue el **server el que la llamó a ella**. Eso es el callback: en el `login` cada cliente le pasa al server su nickname y el proxy de su `ClientCallback`, y el server lo guarda para avisarle cuando pase algo. Como el cliente crea su adaptador sin endpoints (`createObjectAdapter("")`) y lo amarra a la conexión con `setAdapter`, el server le habla por la misma conexión TCP que el cliente abrió, sin que el cliente tenga que abrir puertos.

Con `/help` miramos los comandos que tiene la CLI:

![Comandos de la CLI](imgFun/03_ComandosHelp.png)

```text
  /users               usuarios conectados
  /msg <nick> <texto>  mensaje privado
  /logout              cerrar sesión (permite entrar con otro nick)
  /quit                cerrar sesión y salir
  /call <nick>         llamar por voz a un usuario
  /accept | /reject    contestar o rechazar una llamada entrante
  /hangup              colgar (o cancelar si aún está sonando)
  /mute                silenciar / activar el micrófono en llamada
  /sendfile <nick> <ruta>  enviar un archivo a un usuario
```

### Prueba 2 — Nickname repetido o vacío

Ahora en una cuarta terminal levantamos otro cliente e intentamos entrar como `Alice`, que ya está conectada, después con un nickname vacío y por último como `Carlos`:

![Nickname repetido y vacío](imgFun/04_NicknameRepetidoYVacio.png)

```text
Nickname: Alice
[CLIENT] El nickname 'Alice' ya está en uso
Nickname:
[CLIENT] El nickname no puede estar vacío
Nickname: Carlos
[CLIENT] Sesión iniciada como Carlos. /help para ver comandos.
[CLIENT] Conectados: Alice, Bob, Carlos
```

el server responde con las excepciones del contrato `NickNameInUse` e `InvalidNickname`, y el cliente **no se cae**: las atrapa, muestra el `reason` y vuelve a pedir nickname. Cuando Carlos entra bien, a Bob (y a Alice) les llega `[+] Carlos se conectó`.

### Prueba 3 — Mensajes privados (RF-02)

Bob le escribe a Alice con `/msg`, ella le responde, y después Bob intenta escribirle a `Pedro`, que no existe:

![Mensajes privados](imgFun/05_MensajesPrivados.png)

```text
--- Bob ---
/msg Alice hola Alice, ya quedo lo de los mensajes privados?
[17:25:03] (para Alice) hola Alice, ya quedo lo de los mensajes privados?
[17:25:04] (privado) Alice: si, y ahorita te paso el enunciado del taller
/msg Pedro hola?
[CLIENT] El usuario 'Pedro' no existe o no está conectado
/users
[CLIENT] Conectados: Alice, Bob, Carlos

--- Alice ---
[17:25:03] (privado) Bob: hola Alice, ya quedo lo de los mensajes privados?
/msg Bob si, y ahorita te paso el enunciado del taller
[17:25:04] (para Bob) si, y ahorita te paso el enunciado del taller
```

el mensaje le llega a Alice al instante con hora y remitente, otra vez por callback (`onPrivateMessage`). Que `sendPrivate` retorne sin excepción es la confirmación de que el server lo recibió y se lo pasó al destino; por eso Bob ve su propia línea `(para Alice)`. Cuando el destino no existe el server lanza `UserNotFound` y el cliente lo muestra sin romperse.

### Prueba 4 — Envío de archivos por chunks (RF-04)

Ahora Alice le manda a Bob dos archivos: el PDF del enunciado del taller y una imagen de 1.6 MB. También probamos un archivo que no existe y mandárselo a ella misma:

![Envío de archivos desde Alice](imgFun/06_EnvioArchivosAlice.png)

```text
/sendfile Bob Taller_Evaluativo_Chat_Ice.pdf
[ARCHIVO] Enviando 'Taller_Evaluativo_Chat_Ice.pdf' a Bob...
[ARCHIVO] Enviado 'Taller_Evaluativo_Chat_Ice.pdf' a Bob (3 chunks, 31 ms)
/sendfile Bob foto_prueba.png
[ARCHIVO] Enviando 'foto_prueba.png' a Bob...
[ARCHIVO] Enviado 'foto_prueba.png' a Bob (27 chunks, 39 ms)
/sendfile Bob no_existe.txt
[ARCHIVO] No existe el archivo: /demo/alice/no_existe.txt
/sendfile Alice foto_prueba.png
[ARCHIVO] No puedes enviarte un archivo a ti mismo.
```

y miremos qué le llega a Bob y qué registra el server:

![Recepción en Bob y log del server](imgFun/07_RecepcionArchivosBobYServer.png)

```text
--- Bob ---
[ARCHIVO] Recibiendo 'Taller_Evaluativo_Chat_Ice.pdf' de Alice (187 KB)...
[ARCHIVO] Recibido 'Taller_Evaluativo_Chat_Ice.pdf' de Alice -> /demo/bob/received/Taller_Evaluativo_Chat_Ice.pdf
[ARCHIVO] Recibiendo 'foto_prueba.png' de Alice (1674 KB)...
[ARCHIVO] Recibido 'foto_prueba.png' de Alice -> /demo/bob/received/foto_prueba.png

--- Server ---
[FILE] Alice -> Bob: Taller_Evaluativo_Chat_Ice.pdf (191569 bytes, 3 chunks)
[FILE] Alice -> Bob: foto_prueba.png (1714176 bytes, 27 chunks)
```

el archivo no viaja de una sola vez sino partido en bloques de **64 KB** (65536 bytes), cada uno en un `FileChunk` con el `transferId`, el nombre, el tamaño total, el índice del chunk, el total de chunks y los datos como `sequence<byte>`. Por eso el PDF de 191569 bytes salió en 3 chunks (191569 / 65536 = 2.92, se redondea hacia arriba) y la imagen de 1714176 bytes en 27. Así cada mensaje queda muy por debajo del límite de 1 MB que trae Ice por defecto (`Ice.MessageSizeMax`).

El server solo hace de cartero: valida que los dos tengan sesión y le reenvía cada chunk a Bob con el callback `onFileChunk`; por eso solo imprime una línea por archivo (cuando le llega el chunk 0). Del lado de Bob, cada chunk se escribe directo en el disco en su posición (`índice × 64 KB`) en un archivo temporal `.part`, así no importa si llegan en desorden y no se carga el archivo completo en memoria. Cuando llegan todos se verifica el tamaño y se renombra en la carpeta `received`.

Para comprobar que el archivo llegó idéntico, sacamos el hash SHA-256 del original y del recibido:

![Verificación SHA-256](imgFun/08_VerificacionSHA256.png)

```text
fd5165f98a6752257edd7c3d02c99c9a987f562f3544f6c06d0753577f6db37a  alice/Taller_Evaluativo_Chat_Ice.pdf
fd5165f98a6752257edd7c3d02c99c9a987f562f3544f6c06d0753577f6db37a  bob/received/Taller_Evaluativo_Chat_Ice.pdf
6d6404fcf2c6d7fd06d714418a491b8cbf4142252ee691a8179803491118ef9e  alice/foto_prueba.png
6d6404fcf2c6d7fd06d714418a491b8cbf4142252ee691a8179803491118ef9e  bob/received/foto_prueba.png
```

los hashes son iguales byte a byte, o sea que no se perdió ni se dañó ningún chunk. En Windows se hace lo mismo con `certutil -hashfile <archivo> SHA256`.

### Prueba 5 — Llamada de voz 1 a 1 (RF-05)

Ahora Alice llama a Bob con `/call Bob`, a Bob le suena y contesta con `/accept`:

![Llamada entre Alice y Bob](imgFun/09_LlamadaAliceBob.png)

```text
--- Alice ---
/call Bob
[LLAMADA] Llamando a Bob...
[LLAMADA] Bob contestó. /mute para silenciar, /hangup para colgar.
[AUDIO] Enviando a 192.0.2.2:41777, escuchando en UDP 42221

--- Bob ---
[LLAMADA] Alice te está llamando. /accept o /reject
/accept
[LLAMADA] En llamada con Alice. /mute para silenciar, /hangup para colgar.
[AUDIO] Enviando a 192.0.2.2:42221, escuchando en UDP 41777

--- Server ---
[CALL] Alice llama a Bob (7786e622-136f-4afc-9016-293ab3d43fd9)
[CALL] Bob aceptó la llamada de Alice
```

acá hay dos canales distintos trabajando:

1. La **señalización** (llamar, sonar, contestar, colgar) va por Ice/TCP. `startCall` devuelve un `callId` (un UUID) que identifica la llamada, y el server avisa con los callbacks `onIncomingCall` y `onCallAccepted`.
2. El **audio** va por UDP directo entre los dos clientes, sin pasar por el server. Cada cliente abre un `DatagramSocket` en el puerto 0 (el sistema operativo le da uno libre) y le manda al server solo el puerto, con el host vacío. El server rellena la IP real de cada uno con la IP de su conexión TCP, y le pasa a cada uno la dirección del otro.

Por eso los puertos quedan cruzados: Alice escucha en el `42221` y Bob le manda a ese; Bob escucha en el `41777` y Alice le manda a ese. El audio es PCM de 16 kHz, 16 bits, mono, en paquetes de 20 ms (640 bytes, 50 paquetes por segundo). Usamos UDP porque en voz es mejor perder un paquete que esperar a que se reenvíe tarde.

### Prueba 6 — Usuario ocupado y mute

Mientras Alice y Bob están en llamada, Carlos intenta llamar a Bob, y Alice prueba el `/mute`:

![Usuario ocupado y mute](imgFun/10_UsuarioOcupadoYMute.png)

```text
--- Carlos ---
/call Bob
[LLAMADA] 'Bob' está en otra llamada

--- Alice ---
/mute
[LLAMADA] Micrófono silenciado.
/mute
[LLAMADA] Micrófono activo.
```

el server lleva un mapa de quién está ocupado y responde con la excepción `UserBusy`, así que la llamada de Carlos no interrumpe la que está en curso. Con `/mute` el micrófono se sigue leyendo pero esos paquetes no se mandan; así al quitar el mute no hay retraso acumulado.

### Prueba 7 — Colgar

Alice cuelga con `/hangup`:

![Colgar la llamada](imgFun/11_Colgar.png)

```text
--- Alice ---
/hangup
[LLAMADA] Colgaste.

--- Bob ---
[LLAMADA] Alice colgó.

--- Server ---
[CALL] Alice colgó la llamada 7786e622-136f-4afc-9016-293ab3d43fd9
```

el server borra la llamada, libera a los dos y le avisa a Bob con `onCallEnded`. Cada cliente para el hilo que envía, el que recibe, y cierra el socket UDP, así que se liberan el micrófono, el parlante y el puerto.

### Prueba 8 — Rechazar una llamada

Ahora Carlos llama a Alice y ella la rechaza con `/reject`:

![Rechazar una llamada](imgFun/12_RechazarLlamada.png)

```text
--- Carlos ---
/call Alice
[LLAMADA] Llamando a Alice...
[LLAMADA] Alice rechazó la llamada.

--- Alice ---
[LLAMADA] Carlos te está llamando. /accept o /reject
/reject
[LLAMADA] Llamada rechazada.

--- Server ---
[CALL] Carlos llama a Alice (c8d401fe-1363-41a8-95e3-8bb16808eabd)
[CALL] Alice rechazó la llamada de Carlos
```

a Carlos le llega `onCallRejected` y vuelve a quedar libre para llamar a otra persona.

### Prueba 9 — Desconexión abrupta en plena llamada

Esta es la prueba más pesada. Carlos llama a Bob, Bob contesta, y en plena llamada cerramos la terminal de Bob a la fuerza con `Ctrl+C`, sin que haga `/hangup` ni `/quit`:

![Caída abrupta de Bob en plena llamada](imgFun/13_CaidaAbruptaEnLlamada.png)

```text
--- Bob ---
[LLAMADA] Carlos te está llamando. /accept o /reject
/accept
[LLAMADA] En llamada con Carlos. /mute para silenciar, /hangup para colgar.
[AUDIO] Enviando a 192.0.2.2:43782, escuchando en UDP 33662
^C

--- Carlos ---
[LLAMADA] Bob contestó. /mute para silenciar, /hangup para colgar.
[AUDIO] Enviando a 192.0.2.2:33662, escuchando en UDP 43782
[LLAMADA] Bob colgó.
[-] Bob se desconectó

--- Server ---
-! 10/12/26 17:25:31:536 warning: Ice.ThreadPool.Server-3: connection exception:
   ...
   com.zeroc.Ice.ConnectionLostException
   ...
[SERVER] Sesión cerrada: Bob
[CALL] Bob salió: se termina la llamada 0ad66748-411d-401d-9e1e-229f2291e376

--- Alice ---
[-] Bob se desconectó
/users
[CLIENT] Conectados: Alice, Carlos
```

el server se dio cuenta de inmediato porque la conexión TCP de Bob se cerró. El texto largo que sale en el server **no es un error del programa**: es el aviso que imprime Ice porque en `config.server` tenemos `Ice.Warn.Connections=1`, y nos sirve para ver que la conexión se perdió (`ConnectionLostException`). Después de eso pasa lo importante:

1. El `SessionRegistry` cierra la sesión de Bob y les avisa a todos que salió (`[-] Bob se desconectó`).
2. Como el `CallService` está registrado como listener de logout, se entera de que Bob tenía una llamada abierta, la termina y le avisa a Carlos con `onCallEnded`. Sin esto Carlos se quedaría "en llamada" con alguien que ya no existe y no podría volver a llamar.
3. El `/users` de Alice ya solo muestra a Alice y Carlos, o sea que el estado del server quedó limpio.

Si un cliente se queda colgado sin cerrar la conexión (por ejemplo se va el wifi), el server también lo saca: el cliente manda heartbeats cada 10 s, y si el server no recibe nada en 30 s cierra esa conexión y pasa por este mismo camino.

### Prueba 10 — Tolerancia a fallos: se cae el server

Por último vamos a la terminal del server y lo cerramos con `Ctrl+C`, y desde Alice intentamos mandar un mensaje:

![El servidor se cae](imgFun/14_ServidorCaido.png)

```text
--- Server ---
^C[SERVER] Sesión cerrada: Alice
[SERVER] Sesión cerrada: Carlos

--- Alice ---
[CLIENT] Se perdió la conexión con el servidor.
/msg Carlos sigues ahi?
[CLIENT] Error de comunicación: ::Ice::ConnectionRefusedException

--- Carlos ---
[CLIENT] Se perdió la conexión con el servidor.
```

los clientes reaccionan en dos capas sin reventar:

1. El **close callback** de la conexión detecta la caída apenas el server se cierra e imprime `[CLIENT] Se perdió la conexión con el servidor.`, sin que el usuario tenga que escribir nada.
2. Cuando Alice intenta mandar el mensaje, Ice intenta reconectar al puerto 10000, que ya no acepta conexiones, y el sistema operativo responde **"connection refused"**. Ice lo entrega como `ConnectionRefusedException`, el cliente la captura y muestra un error controlado en vez de un stacktrace.

### Prueba en dos PCs — audio UDP real

Las pruebas de arriba se hicieron con los tres clientes en el mismo equipo. Para comprobar que el audio sí viaja por la red entre equipos distintos, probamos con dos PCs en la misma red wifi: el PC A con IP `192.168.1.16` y el PC B con IP `192.168.1.14`. Primero hicimos ping del PC A al B para ver que se ven:

![Ping entre los dos PCs](imgFun/15_PingEntrePCs.png)

```text
Haciendo ping a 192.168.1.14 con 32 bytes de datos:
Respuesta desde 192.168.1.14: bytes=32 tiempo=7ms TTL=128
...
Paquetes: enviados = 4, recibidos = 4, perdidos = 0
```

y después corrimos la prueba aislada de audio (`AudioTest`) en los dos PCs al tiempo, cada uno mandándole al otro por el puerto UDP 5000:

`.\gradlew :client:runAudioTest -PaudioArgs="192.168.1.16 5000 5000"`

![Prueba de audio UDP en el PC B](imgFun/16_AudioUDPDosPCs.png)

```text
[AUDIO] Escuchando en UDP 5000, enviando a 192.168.1.16:5000
[AUDIO] m = mute/unmute, q = salir
m
[AUDIO] Micrófono silenciado
m
[AUDIO] Micrófono activo
```

se escuchó la voz de un PC en el otro, y el mute funcionó. Algo que aprendimos acá es que con el firewall de Windows activo y la red marcada como **pública**, los paquetes UDP no entraban. La forma correcta de hacerlo es dejar la red como **privada**, el firewall encendido y permitir Java cuando Windows lo pregunte, en vez de apagar el firewall.

Con esto queda demostrado que el chat multimedia con ZeroC Ice funciona correctamente en lo que llevamos: inicio de sesión y presencia en tiempo real con callbacks, mensajes privados, envío de archivos por chunks sin pérdida (verificado con SHA-256), llamadas 1 a 1 con señalización por Ice y audio por UDP, y el manejo de los casos de falla (usuario ocupado, rechazo, desconexión abrupta y caída del server) sin que ningún proceso se caiga.
